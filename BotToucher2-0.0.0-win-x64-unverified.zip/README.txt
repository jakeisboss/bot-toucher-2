Bot Toucher 2 — 0.0 shell

Extract this entire folder, then run BotToucher2.exe on Windows x64.
Keep all files together. No separate .NET runtime is needed.
This is a folder build, not an installer. Windows runtime acceptance is still unverified.

Home / Packet Center / Data / Lab / Settings / Help are shell destinations.
The central workspace is empty. No widget runtime, updater, packets or workloads are implemented.
Hardware observation starts with the app and stops after in-flight sampling drains on close.
Preferences: %LOCALAPPDATA%/BotToucher2/layout.json
